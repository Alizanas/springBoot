-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 01-09-2017 a las 09:30:51
-- Versión del servidor: 10.1.25-MariaDB
-- Versión de PHP: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `spring`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumnos`
--

CREATE TABLE `alumnos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `edad` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `curso`
--

CREATE TABLE `curso` (
  `id` int(11) NOT NULL,
  `asignatura` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `nombre` varchar(256) NOT NULL,
  `descripcion` mediumtext NOT NULL,
  `url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `items`
--

INSERT INTO `items` (`id`, `nombre`, `descripcion`, `url`) VALUES
(1, 'Rosca de churros', 'Para prepararlos tendrás que freír unos panecillos especiales para perritos y luego los rebozas en en azúcar mezclado con canela. Una vez fríos, los abres y los rellenas con una generosa cantidad de crema pastelera.', 'https://i.pinimg.com/736x/f9/98/94/f998943e80e3e11017c3d0a728141971--chocolate-churros-in-spanish.jpg'),
(2, 'Churros de patata', 'Con una masa quebrada cubres la base de un molde. Lo llenas con la crema pastelera y lo cubres con láminas de manzana en crudo y un poco de azúcar. Se hornea y luego se decora con unas cucharadas de mermelada de melocotón o albaricoque.', 'http://www.just-eat.es/blog/wp-content/uploads/2015/09/churros-650-jpg.jpg'),
(3, 'Café con leche', 'Alaska de fresa, barquita de frambuesa, bocadito de nata, bomba de naranja, canutillo de crema, capuchina, disco de chocolate, eclair de caramelo.', 'https://vivelatinoamerica.files.wordpress.com/2015/02/cafe-cappuccino.jpg'),
(4, 'Café solo', 'Bizcocho de chocolate con mousse de chocolate blanco, chocolate de leche y chocolate negro con un baño de chocolate negro brillante.', 'http://www.eboca.com/ebocame/wp-content/uploads/2016/09/El-caf%C3%A9-engorda.jpg'),
(5, 'Café largo', '', 'https://www.productosdelcafe.com/cafessantacristina/img/1largo.jpg'),
(6, 'Chocolate', '', 'http://www.turmix.es/wp-content/uploads/2012/07/chocolate-a-la-taza_banner.jpg');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alumnos`
--
ALTER TABLE `alumnos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `curso`
--
ALTER TABLE `curso`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `alumnos`
--
ALTER TABLE `alumnos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `curso`
--
ALTER TABLE `curso`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `items`
--
ALTER TABLE `items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
